# PATTERNETRATIO
The concept of harmonic patterns in trading was first introduced by H.M. Gartley in his book "Profits in the Stock Market", published in 1935. Gartley observed that markets have a tendency to move in repetitive patterns, and he identified several specific patterns that he believed could be used to predict future price movements.
