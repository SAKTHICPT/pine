// @version=3
//
// Pivot Points indicator, calculated in the "traditional" way, also called "floor-trader pivots".
//
// Additionally, and optional to the user, the halves between the key levels are also shown.
//
// The Default chosen Time Frame to calculate the pivot points is: 
//      Daily (D) if within intraday
//      Weekly (W) if within daily chart
//      Monthly (M) if within weekly chart
//      3 Months (3M) if within monthly chart
//
//
// # Advantages over TV's indicator "Pivot Points Standard"
//      1. Show pivot lines for all history, which lets you gauge trading strategies throughout time
//      2. More sensible Default/Auto time frame; e.g. on intradays only and always the market values of yesterday's Day are used
//      3. The halves between the key levels are also shown, which it's useful for some trading strategies
//      4. Arguably out-of-the-box nicer interface
//      
//
//
// Author: Juan Miguel Cejuela (@juanmirocks)
// Source: https://gist.github.com/juanmirocks/c914bd78dd43e910c5e76f12ceb875f4
// Updated: 2019-05-16
//
study(title="Pivot Points, by @juanmirocks", shorttitle="PP", overlay=true)

defaultTimeFrame = ((isintraday) ? "D" : ((isdaily) ? "W" : ((isweekly) ? "M" : "3M")))
inputTimeFrame = input(title="Time Frame", type=string, defval="Default")
chosenTimeFrame = (inputTimeFrame == "Default") ? defaultTimeFrame : inputTimeFrame

getSeries(e) => security(tickerid, chosenTimeFrame, e, lookahead=barmerge.lookahead_on)

H = getSeries(high[1])
L = getSeries(low[1])
C = getSeries(close[1])

// Main Pivot
P = (H + L + C) / 3 
// Resistence Levels
R3 = H + 2*(P - L)
R2 = P + (H - L)
R1 = (P * 2) - L
// Support Levels
S1 = (P * 2) - H
S2 = P - (H - L)
S3 = L - 2*(H - P)

// Optional Halves between levels
R2_5 = (R2 + R3) / 2 //aka R2.5
R1_5 = (R1 + R2) / 2 //aka R1.5
R0_5 = (P + R1) / 2 //aka R0.5
//
S0_5 = (P + S1) / 2 //aka S0.5
S1_5 = (S1 + S2) / 2 //aka S1.5
S2_5 = (S2 + S3) / 2 //aka S2.5


//UX Input Arguments
pColor = #ffa100
rColor = green
sColor = red
myWidthMainLevels = input(title="Line width for Main levels", type=integer, defval=3, minval=1)
myWidthHalfLevels = input(title="Line width for Half levels", type=integer, defval=1, minval=1)
myStyle = linebr


plot(R3, title="R3", color=rColor, linewidth=myWidthMainLevels, style=myStyle)
plot(R2_5, title="R2.5", color=rColor, linewidth=myWidthHalfLevels, style=myStyle)
plot(R2, title="R2", color=rColor, linewidth=myWidthMainLevels, style=myStyle)
plot(R1_5, title="R1.5", color=rColor, linewidth=myWidthHalfLevels, style=myStyle)
plot(R1, title="R1", color=rColor, linewidth=myWidthMainLevels, style=myStyle)
plot(R0_5, title="R0.5", color=rColor, linewidth=myWidthHalfLevels, style=myStyle)

plot(P, title="P", color=pColor, linewidth=myWidthMainLevels, style=myStyle)

plot(S0_5, title="S0.5", color=sColor, linewidth=myWidthHalfLevels, style=myStyle)
plot(S1, title="S1", color=sColor, linewidth=myWidthMainLevels, style=myStyle)
plot(S1_5, title="S1.5", color=sColor, linewidth=myWidthHalfLevels, style=myStyle)
plot(S2, title="S2", color=sColor, linewidth=myWidthMainLevels, style=myStyle)
plot(S2_5, title="S2.5", color=sColor, linewidth=myWidthHalfLevels, style=myStyle)
plot(S3, title="S3", color=sColor, linewidth=myWidthMainLevels, style=myStyle)