Relevance of this indicator:
1. This indicator is useful because it keeps its levels the same, even when you change the chart's timeframe, making it reliable for analysis.
2. This indicator also displays equal highs and lows, which serve as crucial reference points for analysis.

Reference Videos: The indicator is developed based on the following video contents.

Original The Inner Circle Trader Video:
Video Title: ICT Mentorship Core Content - Month 04 - Reinforcing Liquidity Concepts & Price Delivery
Video Link: https://www.youtube.com/watch?v=npL3ZXJ5zOU

A Simplified Explanation from TTrades:
Video Title: Internal & External Liquidity (Daily Bias) - ICT Concepts
Video Link: https://www.youtube.com/watch?v=3OivsP1j_UE&t=1s

The indicator is based on the following indicator:
Indicator Title: "Pivot mtf semaphore support&resistance [LM]"
Indicator Link: "https://www.tradingview.com/script/OZDSeSQd-Pivot-mtf-semaphore-support-resistance-LM/"

Note:
Please note that the information provided is purely suggested for educational purposes and not intended as promotion. There are no personal preferences involved, and no endorsement of any individual or entity is implied.