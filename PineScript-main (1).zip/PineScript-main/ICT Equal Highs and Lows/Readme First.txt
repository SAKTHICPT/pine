Indicator:
ICT Equal Highs and Lows Indicator: Only the indicator without Screener

Screener:
ICT Equal Highs and Lows with Screener:
Two screening methods are available.
One screens the equal levels.
The other screens when price cross the equal levels.
