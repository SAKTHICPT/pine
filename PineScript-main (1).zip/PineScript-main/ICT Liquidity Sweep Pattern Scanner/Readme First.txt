// Readme First:

// ICT Liquidity Sweep Pattern Scanner

// Logic
//   - This generally identifies bullish or bearish liquidity sweeps of previous 1st, 2nd, or 3rd swings.

// Notes
//   - Use higher timeframes for stock selection and trade in lower timeframes.
//   - The scanner may also generate incorrect signals.