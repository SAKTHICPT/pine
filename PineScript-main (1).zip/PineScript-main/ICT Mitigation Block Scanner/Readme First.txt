// Readme First:

// ICT Mitigation Block Scanner

// Reference
//   - Video Title: ICT Mentorship Core Content - Month 04 - Mitigation Blocks
//   - Video Link: https://www.youtube.com/watch?v=FOUzW0QmsfI

// Notes
//   - For intraday trading, a 3-minute timeframe works well.
//   - The Scanner will generate wrong signals also.