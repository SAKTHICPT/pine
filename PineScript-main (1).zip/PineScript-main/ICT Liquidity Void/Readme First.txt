About this indicator:
1. The application of liquidity voids is often noticed in ICT live trades, especially bearish voids.
2. Similar to equal highs and lows, liquidity voids are important reference points and easily identifiable.
3. The screener filters cross over or cross under to the high or low or the liquidity voids.
4. There are still minor issues existing in the indicator, which will be solved in the future.

Reference Videos: The indicator is developed based on the following video contents.

Original The Inner Circle Trader Video:

Video Title: ICT Mentorship Core Content - Month 04 - Liquidity Voids
Video Link: https://www.youtube.com/watch?v=HTQgH11W37o

Video Title: ICT Mentorship Core Content - Month 1 - Fair Valuation
Video Link: https://www.youtube.com/watch?v=SiVmoeyOWZE

Note:
Please note that the information provided is purely suggested for educational purposes and not intended as promotion.
There are no personal preferences involved, and no endorsement of any individual or entity is implied.